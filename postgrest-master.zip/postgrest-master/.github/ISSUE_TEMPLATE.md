### Environment

* PostgreSQL version: (if using docker, specify the image)
* PostgREST version: (if using docker, specify the image)
* Operating system:

### Description of issue

(Expected behavior vs actual behavior)

(Steps to reproduce: Include a minimal SQL definition plus how you make the request to PostgREST and the response body)
